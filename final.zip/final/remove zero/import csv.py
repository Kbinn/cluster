import csv

input_file = 'ZERO.csv'
output_file = 'remaining_rows.csv'
deleted_rows_file = 'deleted_rows.csv'

with open(input_file, 'r') as csvfile:
    reader = csv.DictReader(csvfile)
    fieldnames = reader.fieldnames

    with open(output_file, 'w', newline='') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()

        remaining_rows = []
        deleted_rows = []

        for row in reader:
            if row['ZERO'] == '0':
                deleted_rows.append(row)
            else:
                remaining_rows.append(row)
                writer.writerow(row)
    with open(deleted_rows_file, 'w', newline='') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(deleted_rows)

print(f"已刪除 {len(deleted_rows)} 列,剩餘列儲存於 {output_file}")
print(f"已將刪除的 {len(deleted_rows)} 列儲存於 {deleted_rows_file}")
